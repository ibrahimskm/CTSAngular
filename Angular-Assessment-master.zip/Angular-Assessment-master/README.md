# Assessment 4

**READ THIS DOCUMENT COMPLETELY BEFORE STARTING THE ASSESSMENT**

## Overview
**Ali Snobba** is a high-end fashion online retailer.  They have a product API at https://developer-service-overspeedy-celebratedness.cfapps.io/products that with provide all of ther products.  They have asked Cognizant to help create the UI.


## Your Task
- Finish this partially done Angular application.  Angular routing has been established, but there is only the redirect route in the app-routing module.
- Finish the application so that it consumes the back-end data and displays it on the product-search page.


## Stories
- As a customer, I can filter search results by brand.
- As a customer, I can filter search results by color.
- As a customer, I can filter search results by price range.
- As a customer, I can combine multiple filters.

## Implementation
- Run npm Install to create the node_modules folder (ommited from Git)
- Create an Angular Class that has the same shape as the test data
coming from the ProductSearch API.
- Create an Angular Service that consumes the API.
- Inject this service into the ProductSearch Component and use it to filter and display the items according to the user's search criteria.

## Test Data (Coming from your ProductSearch API)
```
[
{
category: "dresses",
brand: "Gucci",
color: "yellow",
price: 2270
},
{
category: "dresses",
brand: "Marni",
color: "brown",
price: 999
},
{
category: "dresses",
brand: "Gucci",
color: "red",
price: 1960
},
{
category: "dresses",
brand: "Marni",
color: "pink",
price: 1129
},
{
category: "dresses",
brand: "Bottega veneta",
color: "black",
price: 2200
},
{
category: "Heels",
brand: "Prada",
color: "black",
price: 120
},
{
category: "Heels",
brand: "Victoria Beckham",
color: "blue",
price: 220
},
{
category: "Heels",
brand: "Celine",
color: "red",
price: 99
},
{
category: "Heels",
brand: "Jil Sander",
color: "orange",
price: 139.99
}
]
```

## Technical requirements
- Run NPM Install to load the node_modules folder
- Use Angular CLI and VS Code.
- Write clean, modularized code.
- Use the product search service at https://developer-service-overspeedy-celebratedness.cfapps.io/products as your backing service.  - - - Clone this repo (or download and unzip), then refer to the README included with the search service for details on how to start/use it.

## Notes
- You will be creating an Angular Service and Class from scratch.


## How to Submit Your Work
1. Push your completed work to your own personal Git Repo. (Create one if you don't have one!)
2. Email me the link to the repo.

## Grading Rubric
- 10% - Routing.
- 10% - Product Class.
- 40% - ProductService that executes the get request and returns the Product[].
- 40% - Complete ProductSearchComponent so that the user can filter by brand, color, and price range. (Template already created)

