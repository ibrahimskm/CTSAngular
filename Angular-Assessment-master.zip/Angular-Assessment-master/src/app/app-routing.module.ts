import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductSearchComponent } from './product-search/product-search.component';

//TODO: Add routes for home and product-search 
const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path:'productsearch',component:ProductSearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
