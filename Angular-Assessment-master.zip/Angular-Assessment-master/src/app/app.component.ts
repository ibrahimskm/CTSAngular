import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  searchForm: FormGroup;
  
  constructor(private fb: FormBuilder) {
    this.createForm();
  }

  
  //TODO: Should set the searchForm to a FormBuilder group with a single element 
  //called searchBox.
  createForm() {
    this.searchForm = this.fb.group({
        searchBox: ['']
      }
    )
  }

  search(): void{
    let countryName = this.searchForm.get('searchBox').value;
    //TODO: navigate to the search route passing the above countryName variable as the parameter.
  }

  ngOnInit() { }
}
