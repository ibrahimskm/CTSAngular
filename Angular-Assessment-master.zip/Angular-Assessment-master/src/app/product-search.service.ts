import { Injectable } from '@angular/core';
import { Product } from './product';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map, filter } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductSearchService {
  products: Product[];
  tempProducts: Product[];
  postHeader =  {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };
  private baseURL: string = "https://developer-service-overspeedy-celebratedness.cfapps.io/";
  constructor(private httpClient:HttpClient) { }

  getAllProducts():Observable<Product[]>{
    return this.httpClient.get<Product[]>(this.baseURL+"products")
      .pipe(
        map(response=>{
          this.products = response;
          return response;
        }),
        catchError(this.handleError<any>())
      );
  }
  private handleError<T>( result?: T) {
    return (error: any): Observable<T> => {
      console.log('An Error occured' + error);
      return null;
    }
  }
  getFilteredProducts(color?:string, brand?: string, minPrice?: number, maxPrice?: number){
    return this.products.filter( p => (p.color == color || (color == undefined || !color ))  && 
                                      (p.brand == brand || (brand == undefined || !brand)) && 
                                      (p.price >= minPrice || (minPrice == undefined || !minPrice)) && 
                                      (p.price <= maxPrice || (maxPrice == undefined || !maxPrice))
                               );
  }

}
