import { Component, OnInit } from '@angular/core';
import { ProductSearchService } from '../product-search.service';
import { Product } from '../product';

@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {
  products : Product[];
  brands: string[];
  colors: string[];
  brand: string;
  color: string;
  minPrice?: number;
  maxPrice?:number;
  filteredProducts : Product[];

  constructor(private productSearchService: ProductSearchService) { }

  GetAllProducts(){
    this.productSearchService.getAllProducts().subscribe(
      response => {
        this.products = response;
        this.GetUniqueBrands();
        this.GetUniqueColors();
        this.GetFilteredProducts();
      }
    );  
  }
  GetFilteredProducts() {
    this.filteredProducts = [];
    this.filteredProducts = this.productSearchService.getFilteredProducts(this.color,this.brand,this.minPrice,this.maxPrice);
  }
  GetUniqueColors() {
    if(this.products !== undefined)
    this.colors = [...new Set(this.products.map(item => item.color))];
  }
  GetUniqueBrands(){
    if(this.products !== undefined)
    this.brands = [...new Set(this.products.map(item => item.brand))];
  }
  ngOnInit() {
    this.GetAllProducts();
  }

}
