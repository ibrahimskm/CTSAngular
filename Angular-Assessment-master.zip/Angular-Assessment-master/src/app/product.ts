export class Product {
    constructor(
    public category: string,
    public brand: string,
    public color: string,
    public price: number
    ){}
}
